#!/system/bin/sh

MODDIR=${0%/*}
BINDDIR=/tmp/mi_ext
LOGFILE=$BINDDIR/mi_ext.log

PATHES="
/product/overlay
/product/app
/product/priv-app
/product/lib
/product/framework
/product/media
/product/opcust
/product/data-app
/product/etc/sysconfig
/product/etc/permissions
/system/app
/system/priv-app
/system/framework
/system/etc/sysconfig
/system/etc/permissions
/product/usr
/product/etc/precust_theme
/product/etc/preferred-apps
/product/etc/security
/vendor/etc/camera
/vendor/lib/rfsa/adsp
"

mkdir -p $BINDDIR
echo '' > $LOGFILE

umount -lvf -t overlay /product/bin >> $LOGFILE 2>&1
umount -lvf -t overlay /product/lib64 >> $LOGFILE 2>&1

for p in $PATHES; do
    umount -v -t overlay $p >> $LOGFILE 2>&1
done

mount --bind -o ro $BINDDIR /mnt/vendor/mi_ext/system
mount --bind -o ro $BINDDIR /mi_ext/system
mount --bind -o ro $BINDDIR /mnt/vendor/mi_ext/product
mount --bind -o ro $BINDDIR /mi_ext/product
mount --bind -o ro $BINDDIR /mnt/vendor/mi_ext/vendor
mount --bind -o ro $BINDDIR /mi_ext/vendor
